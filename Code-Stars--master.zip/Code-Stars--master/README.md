# Code-Stars, Presents NBA Live Scores 

## Overview

As an NBA fan I want to:
Check the score of live games
Review the statistics of all teams in the NBA
Learn more about the players I enjoy watching

As the user I want to:
Easily check the live score of current games
Navigate between pages 
Search by player name

## Description of Application

This application is designed to:
Display live NBA scores
Display current standings by conference
Display player information using a search

## Technology Used
API-NBA (RapidAPI)
Materialize (CSS Framework)
Server-side APIs
Moment.js
Jquery

